#!/bin/bash
set -euo pipefail
EXPECTED_VERSION="38.0.143"
APP="/Applications/WaifuX.app"
DEST="$APP/Contents/Resources/Resources"
HERE="$(cd "$(dirname "$0")" && pwd)"

echo "=== WaifuX Intel Video + Web installer ==="

[[ "$(uname -m)" == "x86_64" ]] || { echo "ERROR: Intel x86_64 Mac required."; exit 1; }
[[ -d "$APP" ]] || { echo "ERROR: $APP not found."; exit 1; }
[[ -d "$DEST" ]] || { echo "ERROR: $DEST not found."; exit 1; }

INSTALLED_VERSION=$(/usr/libexec/PlistBuddy -c "Print :CFBundleShortVersionString" "$APP/Contents/Info.plist" 2>/dev/null || true)
echo "Installed WaifuX version: ${INSTALLED_VERSION:-unknown}"
echo "Patch build version:       $EXPECTED_VERSION"
[[ "$INSTALLED_VERSION" == "$EXPECTED_VERSION" ]] || { echo "ERROR: Version mismatch. Build the exact same version."; exit 2; }

for BIN in wallpaper-video-renderer wallpaperengine-cli; do
  [[ -f "$HERE/$BIN" ]] || { echo "ERROR: Missing $BIN"; exit 1; }
  file "$HERE/$BIN" | grep -q 'x86_64' || { echo "ERROR: $BIN is not x86_64"; file "$HERE/$BIN"; exit 1; }
done

osascript -e 'tell application "WaifuX" to quit' 2>/dev/null || true
pkill -f '/WaifuX.app/' 2>/dev/null || true
pkill -f 'wallpaper-video-renderer' 2>/dev/null || true
pkill -f 'wallpaperengine-cli' 2>/dev/null || true
sleep 2

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/Desktop/WaifuX-backup-before-intel-${STAMP}.app"
echo "Creating backup: $BACKUP"
ditto "$APP" "$BACKUP"
printf '%s\n' "$BACKUP" > "$HOME/.waifux_intel_backup_path"

sudo cp "$HERE/wallpaper-video-renderer" "$DEST/wallpaper-video-renderer"
sudo cp "$HERE/wallpaperengine-cli" "$DEST/wallpaperengine-cli"
sudo chmod 755 "$DEST/wallpaper-video-renderer" "$DEST/wallpaperengine-cli"

file "$DEST/wallpaper-video-renderer"
file "$DEST/wallpaperengine-cli"

sudo codesign --force --sign - "$DEST/wallpaper-video-renderer"
sudo codesign --force --sign - "$DEST/wallpaperengine-cli"
sudo codesign --force --deep --sign - --preserve-metadata=identifier,entitlements,requirements,flags,runtime "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"

echo
echo "SUCCESS. Test Media video, Wallpaper Engine Video, and Wallpaper Engine Web."
echo "Scene is intentionally not patched."
