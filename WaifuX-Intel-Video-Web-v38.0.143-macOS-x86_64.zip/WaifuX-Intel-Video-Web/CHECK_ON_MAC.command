#!/bin/bash
set -euo pipefail
APP="/Applications/WaifuX.app"
DEST="$APP/Contents/Resources/Resources"
echo "CPU:"; uname -m
echo "WaifuX version:"; /usr/libexec/PlistBuddy -c "Print :CFBundleShortVersionString" "$APP/Contents/Info.plist" 2>/dev/null || true
echo "Installed binaries:"
file "$DEST/wallpaper-video-renderer" 2>/dev/null || true
file "$DEST/wallpaperengine-cli" 2>/dev/null || true
echo "Scene renderer (not patched):"
file "$DEST/wallpaper-wgpu" 2>/dev/null || true
