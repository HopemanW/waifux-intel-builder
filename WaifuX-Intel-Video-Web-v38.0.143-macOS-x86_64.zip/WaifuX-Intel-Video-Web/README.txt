WaifuX Intel Video + Web patch
Target WaifuX version: 38.0.143
Target Mac CPU: Intel x86_64

Included:
- wallpaper-video-renderer (x86_64)
- wallpaperengine-cli (x86_64)
- INSTALL_ON_MAC.command
- CHECK_ON_MAC.command
- RESTORE_ORIGINAL.command

Not patched: wallpaper-wgpu / dxc / libdxcompiler.dylib (Scene remains unsupported).

On the Intel Mac:
1. Transfer this INNER ZIP intact to the Mac.
2. Extract it on the Mac.
3. Open Terminal and cd into the extracted folder.
4. Run: bash CHECK_ON_MAC.command
5. Confirm the installed WaifuX version is 38.0.143.
6. Run: bash INSTALL_ON_MAC.command
7. Enter the Mac administrator password when sudo asks.
8. Open WaifuX and test Media video, WE Video, and WE Web.
9. To restore: bash RESTORE_ORIGINAL.command
