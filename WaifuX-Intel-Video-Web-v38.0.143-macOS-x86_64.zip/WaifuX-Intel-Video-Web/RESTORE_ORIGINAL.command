#!/bin/bash
set -euo pipefail
APP="/Applications/WaifuX.app"
POINTER="$HOME/.waifux_intel_backup_path"
[[ -f "$POINTER" ]] || { echo "ERROR: No backup pointer found."; exit 1; }
BACKUP="$(cat "$POINTER")"
[[ -d "$BACKUP" ]] || { echo "ERROR: Backup not found: $BACKUP"; exit 1; }
echo "Backup: $BACKUP"
read -r -p "Type RESTORE to replace /Applications/WaifuX.app: " ANSWER
[[ "$ANSWER" == "RESTORE" ]] || exit 0
osascript -e 'tell application "WaifuX" to quit' 2>/dev/null || true
pkill -f '/WaifuX.app/' 2>/dev/null || true
sleep 2
sudo rm -rf "$APP"
sudo ditto "$BACKUP" "$APP"
echo "Original WaifuX restored."
